/* David Wilson (862134618) dwils036@ucr.edu
 * Partner: Hector Soto Jr
 * Lab Section: 23
 * Assignment: Lab 6 Exercise 1
 * AVR timer with LED
 * I acknowledge all content contained herein, excluding template or example
 * code, is my own original work.
 */  

#include <avr/io.h>
#include <avr/interrupt.h>

enum ledseq{init, seq0, seq1, seq2} state;
	


//timer start
volatile unsigned char TimerFlag = 0;
unsigned long _avr_timer_M = 1;
unsigned long _avr_timer_cntcurr = 0;

void TimerOn(){
	TCCR1B = 0x0B;
	OCR1A =125;
	TIMSK1 = 0x02;
	TCNT1 = 0;
	_avr_timer_cntcurr = _avr_timer_M;
	SREG |= 0x80;
};

void TimerOff(){
	TCCR1B = 0x00;
};

void TimerISR(){
	TimerFlag = 1;
};

ISR(TIMER1_COMPA_vect){

	_avr_timer_cntcurr--;
	if(_avr_timer_cntcurr ==0){
		TimerISR();
		_avr_timer_cntcurr = _avr_timer_M;
	}
}

void TimerSet(unsigned long M){
	_avr_timer_M = M;
	_avr_timer_cntcurr = _avr_timer_M;
}
//timer end
void lightSeq()
{
	//transitions
	switch(state){
		case init:
		state = seq0;
		break;
		case seq0:
		state = seq1;
		break;
		case seq1:
		state = seq2;
		break;
		case seq2:
		state = seq0;
		break;
		default:
		state = init;
		break;
	}
	
	//state actions
	switch(state){
		case init:
		break;
		case seq0:
		PORTB = 0x01;
		break;
		case seq1:
		PORTB = 0x02;
		break;
		case seq2:
		PORTB = 0x04;
		break;
		default:
		break;
	}
}

int main(void)
{
	TimerSet(100);
	TimerOn();
	
	DDRB = 0xFF; //initialize B as input
	PORTB = 0x00; 
	
	while (1)
	{
		lightSeq();
		while(!TimerFlag);
		TimerFlag = 0;
	}
}

